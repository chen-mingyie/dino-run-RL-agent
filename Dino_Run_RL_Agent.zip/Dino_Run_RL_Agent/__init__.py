import sys,os
from . import gym_chrome_dino2

sys.path.append(os.path.dirname(os.path.realpath(__file__)))